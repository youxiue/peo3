CREATE TRIGGER T1
  AFTER INSERT OR DELETE
  ON PERSON
  begin
   dbms_output.put_line('新同事走了....');
end;
/

