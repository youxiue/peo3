CREATE TRIGGER AUID
  BEFORE INSERT
  ON PERSON
  FOR EACH ROW
  declare

  begin
    select s_person.nextval into :new.pid from dual;
  end;
/

