CREATE function f_emp(v_eno emp.empno%type) return emp.sal%type
is
   v_sal emp.sal%type;
begin
  select sal into v_sal from emp where empno = v_eno ;
  return v_sal;
end;
/

