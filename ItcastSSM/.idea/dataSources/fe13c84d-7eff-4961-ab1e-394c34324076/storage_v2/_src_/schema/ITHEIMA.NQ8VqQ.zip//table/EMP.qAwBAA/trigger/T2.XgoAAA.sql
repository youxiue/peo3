CREATE TRIGGER T2
  BEFORE UPDATE
  ON EMP
  FOR EACH ROW
  begin
  -- 判断薪资 是不是比之前薪资低
  if :old.sal>:new.sal then
    raise_application_error(-20001,'不能降薪啊,会死人的');
    end if;
end;
/

