CREATE TRIGGER PT
  AFTER INSERT
  ON PERSON
  begin
  dbms_output.put_line('欢迎新同事....');
end;
/

