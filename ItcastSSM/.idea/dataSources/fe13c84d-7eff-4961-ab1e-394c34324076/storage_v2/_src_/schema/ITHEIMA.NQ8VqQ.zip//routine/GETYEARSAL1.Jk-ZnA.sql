CREATE procedure getYearSal1(eno emp.empno%type,yearsal out number)
is

begin
  select  sal*12 + nvl(comm ,0) into yearsal from emp where empno=eno;
end;
/

