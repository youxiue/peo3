CREATE procedure getYearSal2(eno emp.empno%type,yearsal out number)
is
     s emp.sal%type;
     c emp.comm%type;
begin
  select  sal*12,nvl(comm ,0) into s,c from emp where empno=eno;
  yearsal := s+c;
end;
/

