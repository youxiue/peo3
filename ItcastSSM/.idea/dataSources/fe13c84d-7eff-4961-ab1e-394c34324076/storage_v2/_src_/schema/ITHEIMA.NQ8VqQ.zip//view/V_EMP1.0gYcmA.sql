CREATE VIEW V_EMP1 AS
  select ename,sal from emp with read only
/

