CREATE procedure p1(eno emp.empno%type)    --创建过程
is
begin
  update emp set sal=sal+100 where empno =eno;
  --commit;
end;
/

