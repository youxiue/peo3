CREATE function  getYearSal(eno emp.empno%type) return number
is
    yearsal number(10);
begin
    select sal*12 + nvl(comm ,0)into yearsal from emp where empno = eno;
    return yearsal;
end;
/

